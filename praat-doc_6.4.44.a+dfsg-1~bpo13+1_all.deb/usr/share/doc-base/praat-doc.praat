Document: praat
Title: Praat
Author: Paul Boersma and David Weenink 
Abstract: Program for speech analysis and synthesis
 Praat is "doing phonetics by computer".  Through its graphical
 interface, several speech analysis functionalities are available:
 spectrograms, cochleograms, and pitch and formant extraction.
 Articulatory synthesis, as well as synthesis from pitch, formant, and
 intensity are also available.  Other features are segmentation,
 labelling using the phonetic alphabet, and computation of statistics.
 Praat is configurable and extensible through its own scripting
 language and has provisions for communicating with other programs.
 The documentation is a local clone of the website at praat.org.
Section: Science/Medicine

Format: HTML
Index: /usr/share/doc/praat/docs/index.html
Files: /usr/share/doc/praat/docs/*
