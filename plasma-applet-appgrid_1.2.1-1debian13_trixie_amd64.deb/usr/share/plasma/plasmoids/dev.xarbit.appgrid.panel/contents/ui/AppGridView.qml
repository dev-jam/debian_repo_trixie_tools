/*
    SPDX-FileCopyrightText: 2026 AppGrid Contributors
    SPDX-License-Identifier: GPL-2.0-or-later

    Icon grid view for applications with hover shake animation.
*/

import QtQuick
import QtQuick.Layouts
import org.kde.kirigami as Kirigami
import org.kde.plasma.components as PlasmaComponents

GridView {
    id: gridView

    // Number of columns to display.
    property int columns: 6

    // Icon size from configuration (Kirigami pixel size).
    property real iconSize: Kirigami.Units.iconSizes.huge

    // Emitted when a shake-all-icons trigger fires (e.g. on grid open).
    signal shakeAllIcons()

    // Emitted when an app is launched by proxy index.
    signal launched(int index)

    // Emitted when a recent app is launched by storageId.
    signal recentLaunched(string storageId)

    // Emitted when the user right-clicks an app.
    signal contextMenuRequested(int index, string storageId, string desktopFile)

    // --- Shuffle animation state ---
    // Maps proxy index -> icon name override for visual-only icon swaps.
    property var iconSwaps: ({})
    signal shufflesUpdated()

    // Emitted when a shuffle animation should play. The overlay handles the visuals.
    signal shuffleAnimRequested(real fromX, real fromY, real toX, real toY,
                                string fromIcon, string toIcon,
                                int fromIndex, int toIndex)

    // Reference to the overlay container (set by GridPanel)
    property Item shuffleOverlayParent: null

    function shuffleIcon(fromIndex) {
        if (count < 2) return

        // Build list of visible indices (excluding the hovered one)
        var firstVisible = indexAt(contentX, contentY)
        var lastVisible = indexAt(contentX + width - 1, contentY + height - 1)
        if (firstVisible < 0) firstVisible = 0
        if (lastVisible < 0) lastVisible = count - 1

        var candidates = []
        for (var i = firstVisible; i <= lastVisible; i++) {
            if (i !== fromIndex && itemAtIndex(i))
                candidates.push(i)
        }
        if (candidates.length === 0) return

        var otherIndex = candidates[Math.floor(Math.random() * candidates.length)]

        var fromData = appsModel ? appsModel.get(fromIndex) : null
        var otherData = appsModel ? appsModel.get(otherIndex) : null
        if (!fromData || !otherData) return

        var fromIcon = iconSwaps[fromIndex] !== undefined ? iconSwaps[fromIndex] : (fromData.iconName || "application-x-executable")
        var otherIcon = iconSwaps[otherIndex] !== undefined ? iconSwaps[otherIndex] : (otherData.iconName || "application-x-executable")

        var fromItem = itemAtIndex(fromIndex)
        var otherItem = itemAtIndex(otherIndex)
        if (!fromItem || !otherItem || !shuffleOverlayParent) {
            applySwap(fromIndex, otherIndex, fromIcon, otherIcon)
            return
        }

        var fromPos = fromItem.mapToItem(shuffleOverlayParent, fromItem.width / 2 - gridView.iconSize / 2, 0)
        var otherPos = otherItem.mapToItem(shuffleOverlayParent, otherItem.width / 2 - gridView.iconSize / 2, 0)

        shuffleAnimRequested(fromPos.x, fromPos.y, otherPos.x, otherPos.y,
                             fromIcon, otherIcon, fromIndex, otherIndex)
    }

    function applySwap(fromIndex, otherIndex, fromIcon, otherIcon) {
        var newSwaps = Object.assign({}, iconSwaps)
        newSwaps[fromIndex] = otherIcon
        newSwaps[otherIndex] = fromIcon
        iconSwaps = newSwaps
        shufflesUpdated()
    }

    function clearShuffles() {
        iconSwaps = {}
        shufflesUpdated()
    }

    function getDisplayIcon(index) {
        return iconSwaps[index] !== undefined ? iconSwaps[index] : ""
    }

    clip: true
    cacheBuffer: Kirigami.Units.gridUnit * 4
    cellWidth: Math.floor(width / columns)
    cellHeight: iconSize
               + Kirigami.Units.gridUnit * 2
               + Kirigami.Units.smallSpacing * 2
    boundsBehavior: Flickable.StopAtBounds
    keyNavigationEnabled: true
    currentIndex: -1
    highlightFollowsCurrentItem: true

    // Search field to return focus to when typing text
    property Item searchField: null
    // The apps model for section queries
    property var appsModel: null
    // Config toggle for recent apps
    property bool showRecentApps: true
    // Whether we're showing "All" (recents visible)
    // Hidden when sorting by most-used since frequent apps are already at the top.
    readonly property bool showRecents: showRecentApps
                                        && appsModel && !appsModel.filterCategory
                                        && !appsModel.searchText
                                        && appsModel.recentApps.length > 0
                                        && appsModel.sortMode === 0

    // Keyboard navigation index for recent items in header (-1 = not in recents)
    property int recentIndex: -1
    readonly property int recentCount: showRecents ? appsModel.recentApps.length : 0

    function launchRecentByIndex(idx) {
        if (idx >= 0 && idx < recentCount)
            recentLaunched(appsModel.recentApps[idx])
    }

    Keys.onReturnPressed: {
        if (recentIndex >= 0)
            launchRecentByIndex(recentIndex)
        else if (currentIndex >= 0)
            launched(currentIndex)
    }
    Keys.onEnterPressed: {
        if (recentIndex >= 0)
            launchRecentByIndex(recentIndex)
        else if (currentIndex >= 0)
            launched(currentIndex)
    }
    Keys.onUpPressed: {
        if (recentIndex >= 0) {
            // Move up within recents row — go to row above if possible
            var newIdx = recentIndex - columns
            if (newIdx >= 0) {
                recentIndex = newIdx
            } else {
                // At top row of recents, go back to search
                recentIndex = -1
                currentIndex = -1
                if (searchField) searchField.forceActiveFocus()
            }
        } else if (currentIndex >= 0 && currentIndex < columns && showRecents) {
            // At top row of grid, move into recents
            var lastRow = Math.floor((recentCount - 1) / columns)
            recentIndex = Math.min(currentIndex + lastRow * columns, recentCount - 1)
            currentIndex = -1
        } else {
            moveCurrentIndexUp()
        }
    }
    Keys.onDownPressed: {
        if (recentIndex >= 0) {
            var newIdx = recentIndex + columns
            if (newIdx < recentCount) {
                recentIndex = newIdx
            } else {
                // Move from recents into grid
                currentIndex = Math.min(recentIndex % columns, count - 1)
                recentIndex = -1
            }
        } else {
            moveCurrentIndexDown()
        }
    }
    Keys.onLeftPressed: {
        if (recentIndex > 0)
            recentIndex--
        else if (recentIndex < 0)
            moveCurrentIndexLeft()
    }
    Keys.onRightPressed: {
        if (recentIndex >= 0 && recentIndex < recentCount - 1)
            recentIndex++
        else if (recentIndex < 0)
            moveCurrentIndexRight()
    }
    Keys.onPressed: function(event) {
        if (event.text.length > 0 && !event.modifiers && searchField) {
            searchField.forceActiveFocus()
            searchField.text += event.text
            currentIndex = -1
            recentIndex = -1
        }
    }

    onCurrentIndexChanged: {
        if (currentIndex >= 0) recentIndex = -1
    }

    header: RecentAppsHeader {
        width: gridView.width
        height: gridView.showRecents ? implicitHeight : 0
        visible: gridView.showRecents
        appsModel: gridView.appsModel
        cellWidth: gridView.cellWidth
        cellHeight: gridView.cellHeight
        iconSize: gridView.iconSize
        currentRecentIndex: gridView.recentIndex
        gridHasFocus: gridView.activeFocus
        onRecentLaunched: function(storageId) { gridView.recentLaunched(storageId) }

        Connections {
            target: gridView
            function onShakeAllIcons() { gridView.headerItem.shakeAll() }
        }
    }

    highlight: Item {
        Rectangle {
            anchors.centerIn: parent
            width: gridView.cellWidth - Kirigami.Units.smallSpacing * 2
            height: gridView.cellHeight - Kirigami.Units.smallSpacing * 2
            radius: Kirigami.Units.cornerRadius
            color: Qt.rgba(Kirigami.Theme.highlightColor.r,
                           Kirigami.Theme.highlightColor.g,
                           Kirigami.Theme.highlightColor.b, 0.2)
            border.width: 1
            border.color: Qt.rgba(Kirigami.Theme.highlightColor.r,
                                  Kirigami.Theme.highlightColor.g,
                                  Kirigami.Theme.highlightColor.b, 0.6)
            visible: gridView.currentIndex >= 0 && gridView.activeFocus
        }
    }

    delegate: Item {
        id: delegateRoot
        width: gridView.cellWidth
        height: gridView.cellHeight

        AppIconDelegate {
            id: iconDelegate
            anchors.fill: parent
            appName: model.name || ""
            appIcon: model.iconName || "application-x-executable"
            displayIcon: gridView.getDisplayIcon(model.index)
            appGenericName: model.genericName || ""
            isCurrentItem: gridView.currentIndex === model.index
            iconSize: gridView.iconSize
            isNew: gridView.appsModel ? gridView.appsModel.isNewApp(model.storageId || "") : false
            onClicked: function(mouse) {
                if (mouse.button === Qt.RightButton) {
                    gridView.contextMenuRequested(model.index, model.storageId || "", model.desktopFile || "")
                } else {
                    gridView.launched(model.index)
                }
            }
            onShuffleRequested: gridView.shuffleIcon(model.index)
        }

        Connections {
            target: gridView
            function onShakeAllIcons() { iconDelegate.shake() }
            function onShufflesUpdated() {
                iconDelegate.displayIcon = gridView.getDisplayIcon(model.index)
            }
        }
    }
}
