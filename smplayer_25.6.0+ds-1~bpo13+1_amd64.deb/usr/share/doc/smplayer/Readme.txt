    SMPlayer, GUI front-end for mplayer.
    Copyright (C) 2006-2025 Ricardo Villalba <ricardo@smplayer.info>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    -------------------------------------------------------------------------

    SMPlayer intends to be a complete front-end for MPlayer, from basic
    features like playing videos, DVDs, and VCDs to more advanced features
    like support for MPlayer filters and more.

    To know how to compile and install smplayer please read Install.txt.

    There are available two optional packages: smplayer-themes and smplayer-skins.
    They contain some icon themes and skins for smplayer and it's highly recommended
    that you install them too.

    Visit the web for updates:
    http://www.smplayer.info

    Support forum:
    http://forum.smplayer.info

    -------------------------------------------------------------------------

    Third-party:

     * QtSingleApplication from Qt Solutions.
       url: http://qt.gitorious.org/qt-solutions
       license: BSD (see src/qtsingleapplication/qtsingleapplication.h)

     * RestAPI by Jean-Christophe Fillion-Robin, Kitware Inc.
       url: https://github.com/commontk/qRestAPI
       license: Apache License

     * qt-json
       url: https://github.com/qt-json/qt-json
       license: GPL 3 (see src/youtube/qt-json/LICENSE)

    Some icons were taken from:

     * nuvoX
       url: http://www.kde-look.org/content/show.php/nuvoX?content=38467
       license: GPL

     * kfaenza
       url: http://kde-look.org/content/show.php/KFaenza?content=143890
       license: GPL

     * Vista-Inspirate 
        url: http://www.kde-look.org/content/show.php/Vista-Inspirate?content=31585
        license: GPL

     * Crystal Clear
        url: http://www.kde-look.org/content/show.php/Crystal+Clear?content=25668
        license: LGPL

     * Oxygen Team
        url: http://www.iconarchive.com/artist/oxygen-icons.org.html
        license: LGPL

     * WPZOOM Social Networking Icon Pack
        url: http://findicons.com/pack/2336/wpzoom_social_networking_icon
        license: Creative Commons Attribution Share Alike (by-sa)

     * ricebowl-0.2.0
        url: http://www.deviantart.com/deviation/22605468/
        license: LGPL

     * rulesPlayer
       url: http://www.dsource.org/projects/rulesplayer
       license: "use without restrictions at your own risk"

     * mplayer (gmplayer)
       url: http://www.mplayerhq.hu/design7/news.html
       license: GPL

     * kplayer
       url: http://kplayer.sourceforge.net/
       license: GPL

     * Gimp
       url: http://www.gimp.org/
       license: GPL

     * http://en.wikipedia.org/wiki/File:Computer_on_fire.svg
       license: Public Domain

     * http://www.pd4pic.com/anaglyph-3d-cellophane-glasses-3dimensional-movie.html
       license: Public Domain CC0

     * https://commons.wikimedia.org/wiki/File:Chromecast_cast_button_icon.svg
       license: Creative Commons Attribution 3.0 Unported

     * The animations src/default-theme/buffering.gif and src/default-theme/pl_loading.gif
       were created at http://www.ajaxload.info/
       license: Do What The Fuck You Want To Public License (http://www.wtfpl.net)
