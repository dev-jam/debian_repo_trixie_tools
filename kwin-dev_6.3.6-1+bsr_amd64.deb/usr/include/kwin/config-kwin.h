#pragma once
#include <QLatin1String>

#define KWIN_PLUGIN_VERSION_STRING "6.3.6"

#define KWIN_BUILD_DECORATIONS 1
#define KWIN_BUILD_KCMS 1
#define KWIN_BUILD_NOTIFICATIONS 1
#define KWIN_BUILD_SCREENLOCKER 1
#define KWIN_BUILD_TABBOX 1
#define KWIN_BUILD_ACTIVITIES 1
#define KWIN_BUILD_GLOBALSHORTCUTS 1
#define KWIN_BUILD_X11 1
constexpr QLatin1String KWIN_CONFIG("kwinrc");
constexpr QLatin1String KWIN_VERSION_STRING("6.3.6");
constexpr QLatin1String XCB_VERSION_STRING("1.17.0");
constexpr QLatin1String KWIN_KILLER_BIN("/usr/lib/x86_64-linux-gnu/libexec/kwin_killer_helper");
#define HAVE_X11_XCB 1
#define HAVE_X11_XINPUT 1
#define HAVE_GBM_BO_GET_FD_FOR_PLANE 1
#define HAVE_GBM_BO_CREATE_WITH_MODIFIERS2 1
#define HAVE_MEMFD 1
#define HAVE_BREEZE_DECO 1
#define HAVE_SCHED_RESET_ON_FORK 1
#define HAVE_ACCESSIBILITY 1
#define HAVE_XKBCOMMON_NO_SECURE_GETENV 1
#if HAVE_BREEZE_DECO
constexpr QLatin1String BREEZE_KDECORATION_PLUGIN_ID("org.kde.breeze");
#endif
#define HAVE_XWAYLAND_ENABLE_EI_PORTAL 0
#define HAVE_GLX 1
#define HAVE_DL_LIBRARY 1
#define HAVE_WL_DISPLAY_SET_DEFAULT_MAX_BUFFER_SIZE 1
#define HAVE_WL_FIXES 0

constexpr QLatin1String XWAYLAND_SESSION_SCRIPTS("/etc/xdg/Xwayland-session.d");

#define HAVE_LIBINPUT_INPUT_AREA 1
